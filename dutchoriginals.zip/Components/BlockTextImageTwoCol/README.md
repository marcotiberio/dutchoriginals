# Block Text/Image Two Col

Simple formatted text from a „What You See Is What You Get“ editor, wrapped in a max width container for a convenient reading experience. Includes an option to center the text, instead of the classical inline center of the editor itself, to allow for additional custom styling.
