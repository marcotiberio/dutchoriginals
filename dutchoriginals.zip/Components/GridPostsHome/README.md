# Grid Posts Home

Up to 4 latest post teaser items from a selected category (or unfiltered from all posts), with a post thumbnail, excerpt and reading time each.
