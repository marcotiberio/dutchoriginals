# Hero Image Text Half

A full width image with a separate mobile image upload to optimize the crop. Optional formatted text as overlay with a fading background to ensure readability. Linebreaks (br-tags) convert to spaces on mobile for individual text flow control on desktop.
