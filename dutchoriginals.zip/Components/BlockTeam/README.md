# Block Team

Image with optional caption and formatted text side by side on desktop and stacking on mobile. Easily to be used for editorial content. Can be quickly adapted for more controlled layout options with fixed image ratios.
