# Block Image Article

Image with optional caption, multiple size options and optimized responsive image sizes.
