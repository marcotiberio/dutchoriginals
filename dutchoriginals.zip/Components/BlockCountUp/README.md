# Block Count Up

Allows to add multiple numbers that automatically count up when scrolled into viewport. Each number has an icon and can have an optional prefix and suffix.
