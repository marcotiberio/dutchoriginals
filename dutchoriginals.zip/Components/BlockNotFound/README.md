# Block Not Found

Used for "404 Not Found" error pages. Displays formatted text from a WYSIWYG and a link to go back to the homepage. Texts can be edited in Translatable Options.
