# Block Video oEmbed

Instead of embedding a video player directly, this component shows a poster image with an overlaying play button at first only. When clicked, the iframe based embed player is loaded autoplays the video, if the browser supports autoplay. Multiple size options available.
