# Hero Slider

A full width image slider with separate mobile image upload for each slide to optimize the crop. Optional formatted text is shown as an overlay.
