# Navigation Footer

A simple list of links generated from a WordPress menu and a content field, to be easily extended into a more complex website footer.
