# List Icons

Add any number of icons and optional text to highlight features or services. Includes a center option that will also wrap the icon in a colored circle.
