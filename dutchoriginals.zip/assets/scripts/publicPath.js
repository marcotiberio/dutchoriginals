const themeUrl = window.FlyntData.templateDirectoryUri
__webpack_public_path__ = `${themeUrl}/dist/` // eslint-disable-line
